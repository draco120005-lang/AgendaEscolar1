
const formulario = document.getElementById("formCadastro");
const mensagem = document.getElementById("mensagem");

formulario.addEventListener("submit", function(event) {

    event.preventDefault();

    const nome = document.getElementById("nome").value;
    const email = document.getElementById("email").value;
    const senha = document.getElementById("senha").value;

    if (nome === "" || email === "" || senha === "") {
        mensagem.textContent = "Preencha todos os campos.";
        mensagem.style.color = "#A32626";
        return;
    }

    mensagem.textContent = "Cadastro preenchido! Ainda não está conectado ao banco de dados.";
    mensagem.style.color = "#17603A";

});


const formulario = document.getElementById("formLogin");
const mensagem = document.getElementById("mensagem");

formulario.addEventListener("submit", function(event) {

    event.preventDefault();

    const email = document.getElementById("email").value;
    const senha = document.getElementById("senha").value;

    if (email === "" || senha === "") {
        mensagem.textContent = "Preencha todos os campos.";
        mensagem.style.color = "#A32626";
        return;
    }

    mensagem.textContent = "Formulário preenchido! Login ainda não conectado.";
    mensagem.style.color = "#17603A";

});
